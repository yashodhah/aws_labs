from os import environ
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

NUMBER_OF_REQUESTS = 100
TARGET_URL = f"https://{environ.get('TARGET_DOMAIN_NAME')}/api/"

# helper functions to 'render' stuff
def process_response(response):
    return f"{status(response)}, {headers(response)}"

def status(response):
    return f"<span {style(response)}>{response.getcode()} {response.reason}</span>"

def style(response):
    return f"style='color: {'green' if response.getcode() == 200 else 'red'}'"

def headers(response):
    return f"x-amzn-RequestId: {response.headers['x-amzn-RequestId']}"

def process_error(response):
    return f"{status(response)}, {error_headers(response)}"

def error_headers(response):
    return f"Retry-After: {response.headers['Retry-After']}"

def handler(event, context):
    body = f"<pre><span style='font-size: 16px'>Sending {NUMBER_OF_REQUESTS} requests to {TARGET_URL}...\n"
    for counter in range(1, NUMBER_OF_REQUESTS + 1):
        body += f"\n{counter}/ "
        try:
            with urlopen(Request(TARGET_URL, data=None, headers={'User-Agent':'PHPCrawl/1.0'})) as response:
                body += f"response: {process_response(response)}"
        except HTTPError as error:
            body += f"response: {process_error(error)}"
        except URLError as error:
            body += f"error: {error.reason}"
    body += "\nScript executed successfully"
    return {"statusCode": 200, "body": body, "headers": {"Content-Type": "text/html"}}