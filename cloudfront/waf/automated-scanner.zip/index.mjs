/* global fetch */ // for Lambda Console code editor
// process.env.PROTECTED_RESOURCE_URL is the scanned WAF-protected resource
// process.env.RESULTS_BUCKET_NAME is where this code uploads scanning results

// This function is meant to be used as-is on AWS Lambda, no additional building or bundling required.
// AWS SDK for JavaScript is available in the Lambda runtime.

import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
const s3Client = new S3Client({ region: process.env.AWS_REGION });

const fetchForTest = test => fetch('https://' + process.env.PROTECTED_RESOURCE_URL + encodeURI(test.url), test.config);
const stripFetchResponse = response => ({ ok: response.ok, status: response.status }); // leave only interesting parts
const isAttackMitigated = statusCode => statusCode !== 200; // simple mitigation logic for now

const tests = [
  // foundational protection
  { title: 'Cross site scripting (XSS)', description: 'In request body', url: '/api/', config: { method: 'POST', body: '<script>alert(1)</script>' } },
  { title: 'Cross site scripting (XSS)', description: 'In request path', url: '/api/<script>alert(1)</script>' },
  { title: 'SQL injection', description: 'In request cookie', url: '/', config: { headers: { 'Cookie': 'PHPSESSID=123; /**//*!DROP DATABASE db' } } },
  { title: 'SQL injection', description: 'In query strings', url: '/?id=1 UNION SELECT 1,2,3' },
  { title: 'Path traversal attack', description: 'Also known as: directory traversal', url: '/' + encodeURIComponent('../secret-file.json') },

  // more tests
  { title: 'Server-side assets', description: 'Unintended information disclosure', url: '/includes/header.php' },
  { title: 'Common bot', description: 'Self-identifying, scraping bot', url: '/', config: { headers: { 'User-Agent': 'ZyBorg/1.0' } } },
  { title: 'API misuse', description: 'Invalid data in request body', url: '/api/listproducts.php', config: { method: 'POST', body: JSON.stringify({ numrecords: 200 }) } },
  { title: 'Mystery test', description: 'The ultimate test', url: '/', config: { headers: { 'mystery-hint': 'U2VjdXJpdHkgaXMgam9iIHplcm8h' } } },
];

export async function handler() {
  // Run tests
  const fetches = tests.map(test => fetchForTest(test).then(stripFetchResponse));
  const settledFetches = await Promise.allSettled(fetches);
  const fetchResults = settledFetches.map(x => x.value);

  // Collect results
  const results = tests.map((test, i) => ({
    title: test.title,
    description: test.description,
    completed: isAttackMitigated(fetchResults[i].status)
  }));

  // Upload results to S3
  const uploadCommand = new PutObjectCommand({
    Bucket: process.env.RESULTS_BUCKET_NAME,
    Key: 'scanning-results.json',
    Body: Buffer.from(JSON.stringify(results), "utf-8"),
    ContentType: 'application/json',
  });
  await s3Client.send(uploadCommand);
  return 'File uploaded successfully to ' + process.env.RESULTS_BUCKET_NAME;
}
