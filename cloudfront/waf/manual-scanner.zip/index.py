from os import environ
import sys
import urllib.request
from urllib.parse import urljoin, urlencode, quote
import io
from html import escape

# parse HTTP request results
def parse_result(http_response):
    status_code = http_response.getcode()
    if status_code == 403:
        return ('403 Forbidden', 0)
    elif status_code == 200:
        return ('200 OK', 1)
    elif status_code == 404:
        return ('404 Not Found', 2)
    elif status_code == 500:
        return ('500 Server Error', 3)
    elif status_code == 400:
        return ('400 Bad Request', 5)
    else:
        return (f"Unexpected status code: {status_code}", 4)

def handler(event, context):
  # Capture the printed output
  buffer = io.StringIO()
  sys.stdout = buffer

  target = 'https://' + environ['PROTECTED_RESOURCE_URL']

  # tests to execute
  tests = [
      # Baseline tests, should always be green to ensure legitimate traffic isn't being blocked
      {'Name': 'Baseline GET Request', 'Type': 'Baseline', 'exec_string': urljoin(target, "/")},
      {'Name': 'Baseline POST Request', 'Type': 'Baseline', 'exec_string': urljoin(target, "/contact"), 'method': 'POST', 'data': {'message': 'Baseline Test'}},
      {'Name': 'Baseline API Request', 'Type': 'Baseline', 'exec_string': urljoin(target, "/api/data"), 'method': 'POST', 'data': {'message': 'Baseline API Test'}},
      {'Name': 'Baseline Bot Request for Static Files', 'Type': 'Baseline', 'exec_string': urljoin(target, "/files/ui.css"), 'headers': {'User-Agent': 'ZyBorg/1.0'}},

      # SQL injection tests
      {'Name': 'SQL Injection in Query String', 'Type': 'SQLi', 'exec_string': urljoin(target, '/?id=1!SELECT_username,password_FROM_CUSTOMER-INFORMATION--')},
      {'Name': 'SQL Injection in Cookie', 'Type': 'SQLi', 'exec_string': urljoin(target, "/api/data?id=1"), 'headers': {'Cookie': 'PHPSESSID=123; /**//*!DROP DATABASE db --'}},

      # XSS tests
      {'Name': 'Cross Site Scripting (XSS) in Body', 'Type': 'XSS', 'exec_string': urljoin(target, "/contact"), 'method': 'POST', 'data': {'message': '<script>alert(1)</script>'}},
      {'Name': 'Cross Site Scripting (XSS) in URI Path', 'Type': 'XSS', 'exec_string': urljoin(target, quote("/contact/<script>alert(1)</script>"))},
      {'Name': 'Cross Site Scripting (XSS) in Query String', 'Type': 'XSS', 'exec_string': urljoin(target, "/search?key=<script>alert(1)</script>")},

      # Path traversal tests
      {'Name': 'Path Traversal', 'Type': 'Traversal', 'exec_string': f'{target}/{quote(quote("../secret-file.json", safe=""), safe="")}'},

      # Server-side assets tests
      {'Name': 'Server Side Assets', 'Type': 'Includes', 'exec_string': urljoin(target, "/includes/confidential-file.json")},

      # Bad bot tests
      {'Name': 'Bad Bot', 'Type': 'Bad Bot', 'exec_string': urljoin(target, "/api/get"), 'headers': {'User-Agent': 'ZyBorg/1.0'}},

      # API misuse tests
      {'Name': 'API Misuse', 'Type': 'API-Misuse', 'exec_string': urljoin(target, "/api/listproducts.php"), 'method': 'POST', 'data': {'numrecords': 200}},

      # Mystery test
      {'Name': 'Mystery Test', 'Type': 'Mystery', 'exec_string': urljoin(target, "/"), 'headers': {'mystery-hint': 'U2VjdXJpdHkgaXMgam9iIHplcm8h'}}
  ]

  # tests for display purposes
  display_tests = [
      # Baseline tests, should always be green to ensure legitimate traffic isn't being blocked
      {'Name': 'Baseline GET Request', 'Type': 'Baseline', 'exec_string': escape(urljoin(target, "/"))},
      {'Name': 'Baseline POST Request', 'Type': 'Baseline', 'exec_string': escape(urljoin(target, "/contact")), 'method': 'POST', 'data': {'message': 'Baseline Test'}},
      {'Name': 'Baseline API Request', 'Type': 'Baseline', 'exec_string': escape(urljoin(target, "/api/data")), 'method': 'POST', 'data': {'message': 'Baseline API Test'}},
      {'Name': 'Baseline Bot Request for Static Files', 'Type': 'Baseline', 'exec_string': urljoin(target, "/files/ui.css"), 'headers': {'User-Agent': 'ZyBorg/1.0'}},

      # SQL injection tests
      {'Name': 'SQL Injection in Query String', 'Type': 'SQLi', 'exec_string': escape(urljoin(target, '/?id=1!SELECT username,password FROM CUSTOMER-INFORMATION--'))},
      {'Name': 'SQL Injection in Cookie', 'Type': 'SQLi', 'exec_string': escape(urljoin(target, "/api/data?id=1")), 'headers': {'Cookie': escape('PHPSESSID=123; /**//*!DROP DATABASE db --')}},

      # XSS tests
      {'Name': 'Cross Site Scripting (XSS) in Body', 'Type': 'XSS', 'exec_string': (urljoin(target, "/contact")), 'method': 'POST', 'data': {'message': '&lt;script&gt;alert(1)&lt;/script&gt;'}},
      {'Name': 'Cross Site Scripting (XSS) in URI Path', 'Type': 'XSS', 'exec_string': urljoin(target, "/contact/&lt;script&gt;alert(1)&lt;/script&gt;")},
      {'Name': 'Cross Site Scripting (XSS) in Query String', 'Type': 'XSS', 'exec_string': urljoin(target, "/search?&lt;script&gt;alert(1)&lt;/script&gt;")},

      # Path traversal tests
      {'Name': 'Path Traversal', 'Type': 'Traversal', 'exec_string': f'{target}/../secret-file.json'},

      # Server-side assets tests
      {'Name': 'Server Side Assets', 'Type': 'Includes', 'exec_string': escape(urljoin(target, "/includes/confidential-file.json"))},

      # Bad bot tests
      {'Name': 'Bad Bot', 'Type': 'Bad Bot', 'exec_string': escape(urljoin(target, "/")), 'headers': {'User-Agent': escape('ZyBorg/1.0')}},

      # API misuse tests
      {'Name': 'API Misuse', 'Type': 'API-Misuse', 'exec_string': escape(urljoin(target, "/api/listproducts.php")), 'method': 'POST', 'data': {'numrecords': 200}},

      # Mystery test
      {'Name': 'Mystery Test', 'Type': 'Mystery', 'exec_string': escape(urljoin(target, "/")), 'headers': {'mystery-hint': escape('U2VjdXJpdHkgaXMgam9iIHplcm8h')}}
  ]

  print(f'<h2>WAF Tests on Target: {target}</h2>')
  print('\n<hr>')

  # list tests
  line_width = 25
  for single_test, display_test in zip(tests, display_tests):
      url = single_test['exec_string']
      method = single_test.get('method', 'GET')
      headers = single_test.get('headers', {})
      data = single_test.get('data', None)

      try:
          req = urllib.request.Request(url, headers=headers)
          if method == 'POST':
              if data is not None:
                  encoded_data = urlencode({k: str(v) for k, v in data.items()}).encode('utf-8')
                  response = urllib.request.urlopen(req, data=encoded_data)
              else:
                  response = urllib.request.urlopen(req, data=None)
          else:
              response = urllib.request.urlopen(req)

          result_string, ret_code = parse_result(response)
      
          test_name = display_test["Name"].ljust(line_width)
          request_line = f'Request: {method} {display_test["exec_string"]}'
          if 'headers' in display_test:
              request_line += f' -- Headers: {display_test["headers"]}'
          if method == 'POST' and 'data' in display_test:
              request_line += f' -- Data: {display_test["data"]}'
      
          if ret_code == 1 and 'Baseline' not in display_test['Type']:
              output_line = f'{request_line}\n<span class="fail">Test Name: {test_name}<span style="display:inline-block; width:100px;"></span>Result: {result_string}</span>\n<hr>'
          elif ret_code == 1 and "Baseline" in display_test['Type']:
              output_line = f'{request_line}\n<span class="success">Test Name: {test_name}<span style="display:inline-block; width:100px;"></span>Result: {result_string}</span>\n<hr>'
          elif ret_code == 0 and 'Baseline' not in display_test['Type']:
              output_line = f'{request_line}\n<span class="success">Test Name: {test_name}<span style="display:inline-block; width:100px;"></span>Result: {result_string}</span>\n<hr>'
          elif ret_code == 0 and "Baseline" in display_test['Type']:
              output_line = f'{request_line}\n<span class="fail">Test Name: {test_name}<span style="display:inline-block; width:100px;"></span>Result: {result_string}</span>\n<hr>'
          elif ret_code == 2:
              output_line = f'{request_line}\n<span class="info">Test Name: {test_name}<span style="display:inline-block; width:100px;"></span>Result: {result_string}</span>\n<hr>'
          elif ret_code == 3:
              output_line = f'{request_line}\n<span class="warning">Test Name: {test_name}<span style="display:inline-block; width:100px;"></span>Result: {result_string}</span>\n<hr>'
          elif ret_code == 4:
              output_line = f'{request_line}\n<span class="other">Test Name: {test_name}<span style="display:inline-block; width:100px;"></span>Result: {result_string}</span>\n<hr>'
          elif ret_code == 5:  # New condition for 400 Bad Request
              output_line = f'<span class="fail">Request: {request_line}<br>Test Name: {test_name}<span style="display:inline-block; width:100px;"></span>Result: {result_string}</span>\n<hr>'
          else:
              output_line = f'{request_line}\n<span class="other">Test Name: {test_name}<span style="display:inline-block; width:100px;"></span>Result: {result_string}</span>\n<hr>'

          print(output_line)
          
      except urllib.error.HTTPError as e:
          if e.code == 403:  # Handle 403 Forbidden error
              test_name = display_test["Name"].ljust(line_width)
              request_line = f'Request: {method} {display_test["exec_string"]}'
              if 'headers' in display_test:
                  request_line += f' -- Headers: {display_test["headers"]}'
              if method == 'POST' and 'data' in display_test:
                  request_line += f' -- Data: {display_test["data"]}'
              output_line = f'{request_line}\n<span class="success">Test Name: {test_name}<span style="display:inline-block; width:100px;"></span>Result: 403 FORBIDDEN</span>\n<hr>'
              print(output_line)
          elif e.code == 400:  # Handle 400 Bad Request error
              test_name = display_test["Name"].ljust(line_width)
              request_line = f'Request: {method} {display_test["exec_string"]}'
              if 'headers' in display_test:
                  request_line += f' -- Headers: {display_test["headers"]}'
              if method == 'POST' and 'data' in display_test:
                  request_line += f' -- Data: {display_test["data"]}'
              output_line = f'{request_line}\n<span class="success">Test Name: {test_name}<span style="display:inline-block; width:100px;"></span>Result: 400 BAD REQUEST</span>\n<hr>'
              print(output_line)
          else:
              print(f"<span class='error'>Error occurred while making the request: {e.code} - {e.reason}</span>\n<hr>")


  # Get the printed output and return it as the response
  output = buffer.getvalue()
  sys.stdout = sys.__stdout__  # Reset the standard output

  # Split the output by newline and wrap each line in <p> tags
  output_lines = output.split('\n')
  html_output = ''.join([f'<p>{line}</p>' for line in output_lines if line.strip()])

  # Add CSS styles for coloring the output
  css_styles = """
  <style>
      .success { color: green; }
      .fail { color: red; }
      .info { color: blue; }
      .warning { color: orange; }
      .other { color: purple; }
      .error { color: darkred; }
      hr { border: 1px solid black; }
  </style>
  """

  body = css_styles + '<pre>' + html_output + '</pre>'
  return { 'statusCode': 200, 'body': body, 'headers': { 'Content-Type': 'text/html' }}